### MDP Value Iteration and Policy Iteration

import numpy as np
from riverswim import RiverSwim

np.set_printoptions(precision=3)

def bellman_backup(state, action, R, T, gamma, V):
    """
    Perform a single Bellman backup.
    """
    # Immediate reward
    immediate_reward = R[state, action]
    
    # Expected future value
    future_value = 0
    for next_state in range(len(V)):
        transition_prob = T[state, action, next_state]
        future_value += transition_prob * V[next_state]
    
    # Bellman equation
    backup_val = immediate_reward + gamma * future_value
    return backup_val

def policy_evaluation(policy, R, T, gamma, tol=1e-3):
    """
    Compute the value function induced by a given policy for the input MDP
    """
    num_states, num_actions = R.shape
    V = np.zeros(num_states)
    
    while True:
        delta = 0
        for state in range(num_states):
            v = V[state]
            action = policy[state]
            # Calculate new value using Bellman expectation equation
            V[state] = bellman_backup(state, action, R, T, gamma, V)
            delta = max(delta, abs(v - V[state]))
        
        if delta < tol:
            break
            
    return V

def policy_improvement(policy, R, T, V_policy, gamma):
    """
    Given the value function induced by a given policy, perform policy improvement
    """
    num_states, num_actions = R.shape
    new_policy = np.zeros(num_states, dtype=int)
    
    for state in range(num_states):
        # Find action that maximizes the Bellman backup
        best_action = 0
        best_value = -np.inf
        for action in range(num_actions):
            action_value = bellman_backup(state, action, R, T, gamma, V_policy)
            if action_value > best_value:
                best_value = action_value
                best_action = action
        new_policy[state] = best_action
        
    return new_policy   


def policy_iteration(R, T, gamma, tol=1e-3):
    """Runs policy iteration."""
    num_states, num_actions = R.shape
    policy = np.zeros(num_states, dtype=int)  # Start with arbitrary policy
    V_policy = np.zeros(num_states)
    
    while True:
        # Policy Evaluation
        V_policy = policy_evaluation(policy, R, T, gamma, tol)
        
        # Policy Improvement
        new_policy = policy_improvement(policy, R, T, V_policy, gamma)
        
        # Check for convergence
        if np.array_equal(policy, new_policy):
            break
            
        policy = new_policy
        
    return V_policy, policy


def value_iteration(R, T, gamma, tol=1e-3):
    """Runs value iteration."""
    num_states, num_actions = R.shape
    V = np.zeros(num_states)
    policy = np.zeros(num_states, dtype=int)
    
    while True:
        delta = 0
        for state in range(num_states):
            old_value = V[state]
            # Find maximum value over all possible actions
            max_value = -np.inf
            best_action = 0
            for action in range(num_actions):
                action_value = bellman_backup(state, action, R, T, gamma, V)
                if action_value > max_value:
                    max_value = action_value
                    best_action = action
            V[state] = max_value
            policy[state] = best_action
            delta = max(delta, abs(old_value - V[state]))
        
        if delta < tol:
            break
            
    return V, policy

if __name__ == "__main__":
    SEED = 1234
    RIVER_CURRENT = 'WEAK'  # Can be 'WEAK', 'MEDIUM', or 'STRONG'
    assert RIVER_CURRENT in ['WEAK', 'MEDIUM', 'STRONG']
    
    env = RiverSwim(RIVER_CURRENT, SEED)
    R, T = env.get_model()
    discount_factor = 0.99

    print("\n" + "-" * 25 + "\nBeginning Policy Iteration\n" + "-" * 25)
    V_pi, policy_pi = policy_iteration(R, T, gamma=discount_factor, tol=1e-3)
    print("Value Function:")
    print(V_pi)
    print("Optimal Policy (L=Left, R=Right):")
    print([['L', 'R'][a] for a in policy_pi])

    print("\n" + "-" * 25 + "\nBeginning Value Iteration\n" + "-" * 25)
    V_vi, policy_vi = value_iteration(R, T, gamma=discount_factor, tol=1e-3)
    print("Value Function:")
    print(V_vi)
    print("Optimal Policy (L=Left, R=Right):")
    print([['L', 'R'][a] for a in policy_vi])
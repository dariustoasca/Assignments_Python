import numpy as np
import torch
import torch.nn as nn
from network_utils import build_mlp, device, np2torch


class BaselineNetwork(nn.Module):
    """
    Class for implementing Baseline network
    """

    def __init__(self, env, config):
        """
        TODO:
        Create self.network using build_mlp, and create self.optimizer to
        optimize its parameters.
        You should find some values in the config, such as the number of layers,
        the size of the layers, etc.
        """
        super().__init__()
        self.config = config
        self.env = env
        self.baseline = None
        self.lr = self.config.learning_rate
        observation_dim = self.env.observation_space.shape[0]

        self.network = build_mlp(
            input_size=observation_dim,
            output_size=1,
            n_layers=self.config.nn_baseline_layers,
            size=self.config.nn_baseline_size
        ).to(device)

        self.optimizer = torch.optim.Adam(self.network.parameters(), lr=self.lr)

    def forward(self, observations):
        output = self.network(observations).squeeze(-1)
        assert output.ndim == 1
        return output

    def calculate_advantage(self, returns, observations):
        baseline_values = self(observations).detach().cpu().numpy()
        advantages = returns - baseline_values
        return advantages

    def update_baseline(self, returns, observations):
        self.optimizer.zero_grad()
        baseline_predictions = self(observations)
        loss = nn.functional.mse_loss(baseline_predictions, returns)
        loss.backward()
        self.optimizer.step()

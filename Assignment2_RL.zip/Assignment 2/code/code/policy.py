import torch
import torch.nn as nn
import torch.distributions as ptd

from network_utils import np2torch, device


class BasePolicy:
    def action_distribution(self, observations):
        """
        Args:
            observations: torch.Tensor of shape [batch size, dim(observation space)]
        Returns:
            distribution: instance of a subclass of torch.distributions.Distribution

        See https://pytorch.org/docs/stable/distributions.html#distribution

        This is an abstract method and must be overridden by subclasses.
        It will return an object representing the policy's conditional
        distribution(s) given the observations. The distribution will have a
        batch shape matching that of observations, to allow for a different
        distribution for each observation in the batch.
        """
        raise NotImplementedError

    def act(self, observations, return_log_prob=False):
        observations = np2torch(observations)
        dist = self.action_distribution(observations)
        sampled_actions = dist.sample()
        if return_log_prob:
            log_probs = dist.log_prob(sampled_actions)
            return sampled_actions.cpu().numpy(), log_probs.detach().cpu().numpy()
        return sampled_actions.cpu().numpy()


class CategoricalPolicy(BasePolicy, nn.Module):
    def __init__(self, network):
        nn.Module.__init__(self)
        self.network = network

    def action_distribution(self, observations):
        logits = self.network(observations)
        distribution = ptd.Categorical(logits=logits)
        return distribution


class GaussianPolicy(BasePolicy, nn.Module):
    def __init__(self, network, action_dim):
        nn.Module.__init__(self)
        self.network = network
        self.log_std = nn.Parameter(torch.zeros(action_dim))

    def std(self):
        return torch.exp(self.log_std)

    def action_distribution(self, observations):
        means = self.network(observations)
        stds = self.std()
        # Expand std to batch size
        stds = stds.expand_as(means)
        distribution = ptd.Independent(ptd.Normal(loc=means, scale=stds), 1)
        return distribution
